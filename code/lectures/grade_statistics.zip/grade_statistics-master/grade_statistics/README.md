# 使用pyqt5开发的小学生成绩管理系统



> 《面向对象技术》课程设计作业

个人网站：[http://www.yaokui.ltd/](http://www.yaokui.ltd/)

### 数据库

- mysql

  

### 运行

- 程序入口：src/login.py
- 超级管理员账号/密码：admin/admin123



### 界面截图

![image-20210524194905556](img/image-20210524194905556.png)

![image-20210524201350390](img/image-20210524201350390.png)

![image-20210524201415433](img/image-20210524201415433.png)

![image-20210524201433236](img/image-20210524201433236.png)

![image-20210524201549058](img/image-20210524201549058.png)

![image-20210524201606449](img/image-20210524201606449.png)
