# Not so awesome academic posters

Here I share some acaemic posters I used. They are not so awesome but work to the degree I survived the conference poster session. You can start with them to build your own awesome posters. 

* Poster for CVPR'15 paper
![poster1](poster_cvpr15_CAM.jpg)
[download pptx](poster_cvpr15_CAM.pptx?raw=true)

* Poster for CVPR'17 paper
![poster2](poster_cvpr17_ade20k.jpg)
[download pptx](poster_cvpr17_ade20k.pptx?raw=true)

* Poster for ECCV'18 paper
![poster3](poster_eccv18_trn.jpg)
[download pptx](poster_eccv18_trn.pptx?raw=true)

* Poster for ECCV'18 paper. This poster is mainly designed by Tete. 
![poster4](poster_eccv18_upernet.jpg)
[download pptx](poster_eccv18_upernet.pptx?raw=true)

* Poster for CVPR'18 paper. This poster is mainly designed by David Bau. I think the font size is bit small and the content is bit too dense.
![poster5](poster_cvpr18_netdissect.jpg)
[download pptx](http://netdissect.csail.mit.edu/poster/poster_v3.pptx)

FYI: The posters above were presented at some conferences in person. So they used to be printed out with height as 1 meter. If you will present poster online like Gatherly, you might have to significantly increase the font size and reduce the density of the content!
