%% Function to create train and test folds.
function cvpartition =  cv_partition(class)

dis = find(class==1);
dis = dis(randperm(length(dis)));

con = find(class==0);
con = con(randperm(length(con)));

if mod(length(con),10)~= 0
   id_cv_con = randperm(10, mod(length(con),10)); 
end

if mod(length(dis),10)~= 0
   id_cv_dis = randperm(10, mod(length(dis),10));  
end

flag_c = 1;
flag_d = 1;
for c = 1:10
cv_id_dis = dis((c-1)*floor(length(dis)/10)+1:(c-1)*floor(length(dis)/10)+floor(length(dis)/10)  );    
cv_id_con = con((c-1)*floor(length(con)/10)+1:(c-1)*floor(length(con)/10)+floor(length(con)/10)  ); 

if ismember(c,id_cv_con)
cv_id_con = [cv_id_con,con(floor(length(con)/10)*10+flag_c) ];
flag_c = flag_c + 1   ;
end

if ismember(c,id_cv_dis)
cv_id_dis = [cv_id_dis,dis(floor(length(dis)/10)*10+flag_d) ];
flag_d = flag_d + 1   ;
end

cv_id = [cv_id_con,cv_id_dis];
cv_id = cv_id(randperm(length(cv_id)));

train_id_dis = dis(ismember(dis, cv_id_dis)==0);
train_id_con = con(ismember(con, cv_id_con)==0);
train_id = [train_id_con,train_id_dis];
train_id = train_id(randperm(length(train_id)));



cvpartition{c,1} = train_id;

cvpartition{c,2} = cv_id;
end