#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jan 25 19:49:03 2020

@author: sayan
"""

def gpu(x):
    
    x = x.to("cuda")
    
    return(x)
    