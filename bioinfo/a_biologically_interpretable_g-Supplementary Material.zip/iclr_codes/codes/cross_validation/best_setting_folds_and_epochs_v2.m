clear;
s = '.';
result =[];
for i = [47]
    class =[];
    class_pred=[];
    result =[];
    for j=0:9

        ss = dir(sprintf('/mnt/sdb1/sayan/pathway_analysis/att_gcn/hybrid/setting%d/setting/model%d/',i,j));
        [epoch{j+1},name{j+1},maxx(j+1)] = find_last(ss);
    end
    
        class=[];class_pred=[];
        for j=0:9
            cc = name{j+1};

            load(sprintf('/mnt/sdb1/sayan/pathway_analysis/att_gcn/hybrid/setting%d/setting/model%d/%s',i,j,cc{end}));
            class_pred = [class_pred;class_test_pred] ;
            class      = [class;class_test] ;        
        end
            perf = classperf(class,class_pred>0.5,'Positive',[1],'Negative',[0]);
            [~,~,~,auc(i)] = perfcurve(class,class_pred,1);
            result(i,:) = [i, perf.CorrectRate, perf.Sensitivity, perf.Specificity, auc(i)];
            class_store{i,1} = class;
            class_store{i,2} = class_pred;
            perff{i,1} = class;
            perff{i,2} = class_pred;



    result_f(i,:)= result(i,:);
    
    [x,y] = perfcurve(perff{i,1},perff{i,2},1);
    figure(1), plot(x,y); hold on;
    
    perf = classperf(class_store{i,1},class_store{i,2}>0.5,'Positive',[1],'Negative',[0]);
    


%     
%     [~,~,~,auc] = perfcurve(class,class_pred,1);
%     


end

function [id,name,max] = find_last(ss)
n = size(ss);
max = 0 ;
tt=1;
id=[];
for i =3:n
    cc = ss(i).name;
    if cc(1:3)=='vis'    
     temp = str2num(cc(4:end-4));
     id = [id,temp];
     name{tt} = cc;
     tt = tt+1;
     if temp>max
     max = temp;
     end

    end
    
end

[id,ind]= sort(id,'ascend');
name = name(ind);

end
