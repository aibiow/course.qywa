#!/bin/bash -l
#SBATCH
#SBATCH --job-name=pway_ann
#SBATCH --time=7:00:0
#SBATCH -p gpuk80
#SBATCH --gres=gpu:1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=6
#SBATCH --array=0-99
# number of cpus (threads) per task (process)

#### load and unload modules you may need
#module load python/3.7-anaconda
module load cuda/9.2
source activate my_root
CUDA_VISIBLE_DEVICES=0 python3.7 wrapper_img.py $SLURM_ARRAY_TASK_ID
