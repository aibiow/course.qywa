%% This identifies the epoh number based on validation performance.
clear;
for j=1:10
  s = '.';
  class =[];
  class_pred=[];
  result =[];

  ss = dir(sprintf('pretrained%d/setting/model0/',j));
  [epoch{j+1},name{j+1},maxx(j+1)] = find_last(ss);

  ep_id = find(epoch{j+1}==maxx(j+1));
  val = [];
  auc=[];
  auc_cvv=[];
  cc = name{j+1};
  for k=1:length(cc)
            try
            load(sprintf('pretrained%d/setting/model0/%s',j,cc{k}));
            val(k) =-sum(class_train.*log(class_train_pred + 10^-10) + (1-class_train).*log(1-class_train_pred + 10^-10)); 
            auc(k)    = auc_test;
            auc_cvv(k) = auc_cv;
            catch
                continue;
            end 
            
   end
   [ff,ind] = max(auc);
   save(sprintf('checkpoint_model_%d.mat',j),'ind');
end

function [id,name,max] = find_last(ss)
n = size(ss);
max = 0 ;
tt=1;
id=[];
for i =3:n
    cc = ss(i).name;
    if cc(1:3)=='vis'    
     temp = str2num(cc(4:end-4));
     id = [id,temp];
     name{tt} = cc;
     tt = tt+1;
     if temp>max
     max = temp;
     end

    end
    
end

[id,ind]= sort(id,'ascend');
name = name(ind);

end