#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Apr 15 13:04:19 2021

@author: sayan
"""
import os
import numpy as np
import pickle
   

def save_object(obj, filename):
    with open(filename, 'wb') as output:  # Overwrites any existing file.
        pickle.dump(obj, output, pickle.HIGHEST_PROTOCOL)
        
def load_object(filename):
    with open(filename, 'rb') as input:  # Overwrites any existing file.
        obj = pickle.load(input)
    return obj

index = []
# identifies how many paths have been examined by LRT.
for root, dirs, files in os.walk("interactions/model"):
    for filename in files:
        print(filename[3:-4])
        index.append(int(filename[3:-4]))

l = list(range(14881)) # 14881 is the total number of paths
for ll in index:
    l.remove(ll)
arr = []    
flag = 0
while True:
    t = []
    for i in range(20):
        if l:
            t.append(l.pop(0))
        else:
            flag=1
            break
    arr = arr+[t]
    
    if flag==1:
        break

save_object(arr, 'remaining_paths3.pkl')