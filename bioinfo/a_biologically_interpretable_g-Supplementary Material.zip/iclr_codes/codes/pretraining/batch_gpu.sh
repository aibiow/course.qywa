#!/bin/bash -l

#SBATCH
#SBATCH --job-name=pway_ann
#SBATCH --time=12:00:0
#SBATCH -p gpuk80
#SBATCH --gres=gpu:2
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=6
# number of cpus (threads) per task (process)

#### load and unload modules you may need
#module load python/3.7-anaconda
module load cuda/9.2
source activate my_root
python3.7 wrapper.py
